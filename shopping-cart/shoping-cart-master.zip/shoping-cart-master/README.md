<p align="center">
  <a href="https://manik-roy.github.io/shoping-cart/">
    <img alt="manikroy" src="https://i.ibb.co/0GNrgFM/image.png" width="750px" />
  </a>
</p>
<h1 align="center">
  Shoping cart with vanila js
</h1>

